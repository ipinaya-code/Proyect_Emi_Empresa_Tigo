﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Empresa_Tigo
{
    public partial class FormLoginAdmi : Form
    {
        public FormLoginAdmi()
        {
            InitializeComponent();
        }

        private void btnEntrar_Click(object sender, EventArgs e)
        {
            string login = txtLogin.Text.Trim();
            string password = txtPassword.Text.Trim();

            if (login == "admi" && password == "admi")
            {
                // Login exitoso
                this.DialogResult = DialogResult.OK;
                this.Close();
            }
            else
            {
                // Error de login
                MessageBox.Show("Login o Password incorrectos.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
