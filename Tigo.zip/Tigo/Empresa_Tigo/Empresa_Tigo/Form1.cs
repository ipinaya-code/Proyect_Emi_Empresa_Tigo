﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Empresa_Tigo.form;
using FontAwesome.Sharp;
namespace Empresa_Tigo
{
    public partial class Form1 : Form
    {
        //campos
        private IconButton currentBtn;
        private Panel leftBorderBtn;
        private Form currentChildForm;
        public Form1()
        {
            InitializeComponent();
            leftBorderBtn = new Panel();
            leftBorderBtn.Size = new Size(7,73);
            Panel_Menu.Controls.Add(leftBorderBtn);
            

        }
        private struct colorRGB
        {
            public static Color color1 = Color.FromArgb(172, 126, 241);
            public static Color color2 = Color.FromArgb(249, 118, 176);
            public static Color color3 = Color.FromArgb(253, 138, 114);
            public static Color color4 = Color.FromArgb(95, 77, 221);
            public static Color color5 = Color.FromArgb(249, 88, 155);
            public static Color color6 = Color.FromArgb(24, 161, 251);
        }
        private void ActivateButton(object senderBtn, Color color)
        {
            if (senderBtn != null)
            {
                DisableButton();
                ///
                currentBtn =(IconButton)senderBtn;
                currentBtn.BackColor = Color.FromArgb(37,36,81);
                currentBtn.ForeColor = color;
                currentBtn.TextAlign=ContentAlignment.MiddleCenter;
                currentBtn.IconColor = color;
                currentBtn.TextImageRelation=TextImageRelation.TextBeforeImage;
                currentBtn.ImageAlign=ContentAlignment.MiddleRight;
                ///
                leftBorderBtn.BackColor = color;
                leftBorderBtn.Location = new Point(0, currentBtn.Location.Y);
                leftBorderBtn.Visible = true;
                leftBorderBtn.BringToFront();
                ///
                iconCurrentChildFo.IconChar = currentBtn.IconChar;
                iconCurrentChildFo.IconColor= color;
            }

        }
        private void DisableButton()
        {
            if (currentBtn != null)
            {
                currentBtn.BackColor = Color.FromArgb(25, 25, 112);
                currentBtn.ForeColor = Color.White;
                currentBtn.TextAlign = ContentAlignment.MiddleLeft;//ala
                currentBtn.IconColor = Color.White;
                currentBtn.TextImageRelation = TextImageRelation.ImageBeforeText;
                currentBtn.ImageAlign = ContentAlignment.MiddleLeft;
            }
        }
        private void OpenChildForm(Form childForm)
        {
            if (currentChildForm != null)
            {
                currentChildForm.Close();
            }
            currentChildForm = childForm;
            childForm.TopLevel = false;
            childForm.FormBorderStyle = FormBorderStyle.None;
            childForm.Dock=DockStyle.Fill;
            panelDesck.Controls.Add(childForm);
            panelDesck.Tag = childForm;
            childForm.BringToFront();
            childForm.Show();
            label1.Text = childForm.Text;

        }
        private void btnNuevoCliente_Click(object sender, EventArgs e)
        {
            ActivateButton(sender, colorRGB.color1);
            OpenChildForm(new FormCliente());
        }

        private void btnClienteRegistrado_Click(object sender, EventArgs e)
        {
            ActivateButton(sender, colorRGB.color2);

            // Mostrar primero el formulario de login del cliente
            FormLoginCliente formLogin = new FormLoginCliente();
            if (formLogin.ShowDialog() == DialogResult.OK)
            {
                // Si el login fue exitoso, abres el formulario de registrado
                OpenChildForm(new FormRegistrado());
            }

        }

        private void btnPaquetes_Click(object sender, EventArgs e)
        {
            ActivateButton(sender, colorRGB.color3);
            OpenChildForm(new FormPaquetes());
        }

        private void btnReducirPaquetes_Click(object sender, EventArgs e)
        {
            ActivateButton(sender, colorRGB.color4);
            OpenChildForm(new FormPaquetes());
            FormLoginCliente formLogin = new FormLoginCliente();
            if (formLogin.ShowDialog() == DialogResult.OK)
            {
                // Si el login fue exitoso, abres el formulario de registrado
                OpenChildForm(new FormReducir());
            }
            
        }
        private void btnUsuario_Click(object sender, EventArgs e)
        {
            //arreglar 
            ActivateButton(sender, colorRGB.color6);
            OpenChildForm(new FormPaquetes());
            FormLoginAdmi formLogin = new FormLoginAdmi();
            if (formLogin.ShowDialog() == DialogResult.OK)
            {
                OpenChildForm(new FormAdmi());
            }


        }

        private void btnHome_Click(object sender, EventArgs e)
        {
            currentChildForm.Close();
            Reset();
        }
        private void Reset()
        {
            DisableButton();
            leftBorderBtn.Visible= false;
            iconCurrentChildFo.IconChar = IconChar.Home;
            iconCurrentChildFo.IconColor = Color.MediumBlue;
            label1.Text = "aqui";
        }
        [DllImport("user32.DLL", EntryPoint = "ReleaseCapture")]
        private extern static void RealeaseCapture();
        [DllImport("user32.DLL", EntryPoint = "SendMessage")]
        private extern static void SendMessage(System.IntPtr hWnd,int wMsg,int wParam,int lParam);

        private void panelBar_MouseDown(object sender, MouseEventArgs e)
        {
            RealeaseCapture();
            SendMessage(this.Handle, 0x112, 0xf012, 0);
        }

        private void btnCerrar_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnMaximizar_Click(object sender, EventArgs e)
        {
            if(WindowState == FormWindowState.Normal)
                WindowState = FormWindowState.Maximized;
            else
                WindowState=FormWindowState.Normal;
        }

        private void btnMinimizar_Click(object sender, EventArgs e)
        {
            WindowState = FormWindowState.Minimized;
        }
    }
}
