﻿using System;
using Empresa_Tigo.Clases;
namespace Empresa_Tigo.Interface
{
    public interface IUsuarioState
    {
        bool PuedeAcceder();
        void ManejarPago(Cliente usuario);
        void ManejarVencimiento(Cliente usuario);
    }
}