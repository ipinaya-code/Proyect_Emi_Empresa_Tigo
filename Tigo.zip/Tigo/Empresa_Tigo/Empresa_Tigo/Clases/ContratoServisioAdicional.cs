﻿using System;

namespace TuProyecto.Models
{
    public class ContratoServicioAdicional
    {
        private int id;
        private DateTime fecha_inicio;
        private DateTime fecha_fin;
        private int id_contrato;
        private int id_servicio_adicional;

        public ContratoServicioAdicional(int id,DateTime fecha_inicio,DateTime fecha_fin,int id_contrato,int id_servicio_adicional)
        {
            this.id = id;
            this.fecha_inicio = fecha_inicio;
            this.fecha_fin = fecha_fin;
            this.id_contrato = id_contrato;
            this.id_servicio_adicional = id_servicio_adicional;
        }

        public int Id { get => id; set => id = value; }
        public DateTime FechaInicio { get => fecha_inicio; set => fecha_inicio = value; }
        public DateTime FechaFin { get => fecha_fin; set => fecha_fin = value; }
        public int IdContrato { get => id_contrato; set => id_contrato = value; }
        public int IdServicioAdicional { get => id_servicio_adicional; set => id_servicio_adicional = value; }
    }
}
