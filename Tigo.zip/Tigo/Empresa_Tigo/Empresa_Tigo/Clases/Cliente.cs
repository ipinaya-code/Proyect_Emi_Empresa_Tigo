﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Empresa_Tigo.Interface;

namespace Empresa_Tigo.Clases
{
    public class ActivoState : IUsuarioState
    {
        public bool PuedeAcceder() => true;

        public void ManejarPago(Cliente usuario){}

        public void ManejarVencimiento(Cliente usuario){usuario.SetState(new InactivoState());}
    }
    public class InactivoState : IUsuarioState
    {
        public bool PuedeAcceder() => false;

        public void ManejarPago(Cliente usuario){usuario.SetState(new ActivoState());}

        public void ManejarVencimiento(Cliente usuario){}
    }

    public class Cliente
    {
        private int id_cliente;
        private string nombre_completo;
        private string apellido_completo;
        private string ci;
        private string telefono;
        private string email;
        private string login;
        private string password;
        private IUsuarioState _state;

        public Cliente(int id_cliente,string nombre_cliente,string apellido_cliente,string ci,string telefono,string email,string login,string password,bool estadoInicial)  // viene de la columna bit 'estado')
        {
            this.id_cliente = id_cliente;
            this.nombre_completo = nombre_cliente;
            this.apellido_completo = apellido_cliente;
            this.ci = ci;
            this.telefono = telefono;
            this.email = email;
            this.login = login;
            this.password = password;
            _state = estadoInicial? (IUsuarioState)new ActivoState(): new InactivoState();
        }
        public int IdCliente => id_cliente;
        public string NombreCliente => nombre_completo;
        public string ApellidoCliente => apellido_completo;
        public string Ci => ci;
        public string Telefono => telefono;
        public string Email => email;
        public string Login => login;
        public string Password => password;
        public bool Estado
        {
            get => _state.PuedeAcceder();
            set => _state = value? (IUsuarioState)new ActivoState(): new InactivoState();
        }
        public void SetState(IUsuarioState nuevoEstado)=> _state = nuevoEstado;
        public bool PuedeAcceder() => _state.PuedeAcceder();
        public void ManejarPago() => _state.ManejarPago(this);
        public void ManejarVencimiento() => _state.ManejarVencimiento(this);
    }

}
