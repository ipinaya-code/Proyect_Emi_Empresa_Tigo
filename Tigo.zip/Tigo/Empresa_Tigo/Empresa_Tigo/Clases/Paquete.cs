﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Empresa_Tigo.Clases
{
    public class Paquete
    {
        private int id_paquete;
        private string nombre;
        private string compro;
        private decimal costo;

        public Paquete(int id_paquete,string nombre,string compro,decimal costo)
        {
            this.id_paquete = id_paquete;
            this.nombre = nombre;
            this.compro = compro;
            this.costo = costo;
        }

        public int IdPaquete { get => id_paquete; set => id_paquete = value; }
        public string Nombre { get => nombre; set => nombre = value; }
        public string Canales { get => compro; set => compro = value; }
        public decimal Costo { get => costo; set => costo = value; }
    }
}
