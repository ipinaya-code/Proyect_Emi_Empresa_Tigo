﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Empresa_Tigo.Clases
{
    public class Pago
    {
        private int id_pago;
        private DateTime fecha_pago;
        private decimal monto;
        private bool estado;
        private int id_contrato;
        public Pago(int id_pago,DateTime fecha_pago,decimal monto,bool estado,int id_contrato)
        {
            this.id_pago = id_pago;
            this.fecha_pago = fecha_pago;
            this.monto = monto;
            this.estado = estado;
            this.id_contrato = id_contrato;
        }
        public int IdPago { get => id_pago; set => id_pago = value; }
        public DateTime FechaPago { get => fecha_pago; set => fecha_pago = value; }
        public decimal Monto { get => monto; set => monto = value; }
        public bool Estado { get => estado; set => estado = value; }
        public int IdContrato { get => id_contrato; set => id_contrato = value; }
    }
}