﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace Empresa_Tigo.Clases
{
    public class BaseDatos
    {
        private string conexion_str;
        public BaseDatos()
        {
            conexion_str = @"Data Source=DESKTOP-PAGR342\SQLEXPRESS;Initial Catalog=bd_Tigo;Integrated Security=True;Encrypt=False";
        }

        public SqlConnection ObtenerConexion()
        {
            return new SqlConnection(conexion_str);
        }

        public void CrearUsuario(string nombreCompleto, string apellidoCompleto, string ci, string telefono, string email, string login, string password, bool estado)
        {
            using (SqlConnection conexionSQL = ObtenerConexion())

            {
                try
                {
                    conexionSQL.Open();

                    string sql = @"
                            INSERT INTO Cliente
                              (nombre_completo, apellido_completo, ci, telefono, email, login, password, estado)
                            VALUES
                              (@nombreCompleto,
                               @apellidoCompleto,
                               @ci,
                               @telefono,
                               @email,
                               @login,
                               @password,
                               @estado);";

                    var cmd = new SqlCommand(sql, conexionSQL);

                    cmd.Parameters.AddWithValue("@nombreCompleto", nombreCompleto);
                    cmd.Parameters.AddWithValue("@apellidoCompleto", apellidoCompleto);
                    cmd.Parameters.AddWithValue("@ci", ci);
                    cmd.Parameters.AddWithValue("@telefono", telefono);
                    cmd.Parameters.AddWithValue("@email", email);
                    cmd.Parameters.AddWithValue("@login", login);
                    cmd.Parameters.AddWithValue("@password", password);
                    cmd.Parameters.AddWithValue("@estado", estado ? 1 : 0);

                    cmd.ExecuteNonQuery();

                    MessageBox.Show("Usuario correctamente insertado");
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Error en la conexión: {ex.Message}", "Error");
                }
            }
        }

        public void ActualizarUsuario(Cliente usuario)
        {
            using (SqlConnection conexion = ObtenerConexion())
            {
                try
                {
                    conexion.Open();
                    string sql = @"UPDATE Cliente SET
                           nombre_completo = @nombre_completo,
                           apellido_completo = @apellido_completo,
                           ci = @ci,
                           telefono = @telefono,
                           email = @email,
                           login = @login,
                           password = @password,
                           estado = @estado
                           WHERE id_cliente = @id_cliente";
                    using (SqlCommand cmd = new SqlCommand(sql, conexion))
                    {
                        cmd.Parameters.AddWithValue("@nombre_completo", usuario.NombreCliente);
                        cmd.Parameters.AddWithValue("@apellido_completo", usuario.ApellidoCliente);
                        cmd.Parameters.AddWithValue("@ci", usuario.Ci);
                        cmd.Parameters.AddWithValue("@telefono", usuario.Telefono);
                        cmd.Parameters.AddWithValue("@email", usuario.Email);
                        cmd.Parameters.AddWithValue("@login", usuario.Login);
                        cmd.Parameters.AddWithValue("@password", usuario.Password);
                        cmd.Parameters.AddWithValue("@estado", usuario.Estado ? 1 : 0);
                        cmd.Parameters.AddWithValue("@id_cliente", usuario.IdCliente);

                        cmd.ExecuteNonQuery();
                        MessageBox.Show("Usuario actualizado correctamente");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Error en la conexión: {ex.Message}", "Error");
                }
            }
        }

        public Cliente BuscarPorId(int id_cliente)
        {
            Cliente usuario = null;
            string query = @"SELECT id_cliente, nombre_completo, apellido_completo, ci, telefono, email, login, password, estado
                     FROM Cliente WHERE id_cliente = @id_cliente";

            using (SqlConnection conexion = ObtenerConexion())
            {
                try
                {
                    conexion.Open();
                    using (SqlCommand cmd = new SqlCommand(query, conexion))
                    {
                        cmd.Parameters.AddWithValue("@id_cliente", id_cliente);
                        using (SqlDataReader reader = cmd.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                usuario = new Cliente(
                                    reader.GetInt32(0),
                                    reader.GetString(1),
                                    reader.GetString(2),
                                    reader.GetString(3),
                                    reader.GetString(4),
                                    reader.GetString(5),
                                    reader.GetString(6),
                                    reader.GetString(7),
                                    reader.GetBoolean(8)
                                );
                            }
                        }
                    }
                }
                catch (Exception e)
                {
                    MessageBox.Show($"Error al buscar usuario: {e.Message}", "Error");
                }
            }

            return usuario;
        }

        public void EliminarUsuario(int id_cliente)
        {
            string query = @"DELETE FROM Cliente WHERE id_cliente = @id_cliente";

            using (SqlConnection conexion = ObtenerConexion())
            {
                try
                {
                    conexion.Open();
                    using (SqlCommand cmd = new SqlCommand(query, conexion))
                    {
                        cmd.Parameters.AddWithValue("@id_cliente", id_cliente);
                        int filas = cmd.ExecuteNonQuery();
                        MessageBox.Show(
                            filas > 0 ? "Usuario eliminado correctamente." : "No se encontró el usuario.",
                            "Resultado");
                    }
                }
                catch (Exception e)
                {
                    MessageBox.Show($"Error al eliminar usuario: {e.Message}", "Error");
                }
            }
        }


        public Cliente BuscarPorLoginYPassword(string login, string password)
        {
            Cliente cliente = null;

            string query = @"
            SELECT id_cliente, nombre_completo, apellido_completo, ci, telefono, email, login, password, estado
            FROM Cliente
            WHERE login = @login AND password = @password;";

            using (SqlConnection conexion = ObtenerConexion())
            {
                try
                {
                    conexion.Open();

                    using (SqlCommand cmd = new SqlCommand(query, conexion))
                    {
                        cmd.Parameters.AddWithValue("@login", login);
                        cmd.Parameters.AddWithValue("@password", password);

                        using (SqlDataReader reader = cmd.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                cliente = new Cliente(
                                    reader.GetInt32(reader.GetOrdinal("id_cliente")),
                                    reader.GetString(reader.GetOrdinal("nombre_completo")),
                                    reader.GetString(reader.GetOrdinal("apellido_completo")),
                                    reader.GetString(reader.GetOrdinal("ci")),
                                    reader.GetString(reader.GetOrdinal("telefono")),
                                    reader.GetString(reader.GetOrdinal("email")),
                                    reader.GetString(reader.GetOrdinal("login")),
                                    reader.GetString(reader.GetOrdinal("password")),
                                    reader.GetBoolean(reader.GetOrdinal("estado"))
                                );
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Error al buscar cliente: {ex.Message}", "Error");
                }
            }

            return cliente;
        }

        public DataTable ObtenerPaquetes()
        {
            DataTable tabla = new DataTable();
            string query = "SELECT nombre_paquete, compro_paquete, costo_paquete FROM Paquete";

            using (SqlConnection conexion = ObtenerConexion())
            {
                try
                {
                    conexion.Open();
                    using (SqlDataAdapter adaptador = new SqlDataAdapter(query, conexion))
                    {
                        adaptador.Fill(tabla);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Error al obtener los paquetes: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }

            return tabla;
        }
        public DataTable ObtenerServiciosAdicionales()
        {
            DataTable tabla = new DataTable();
            string query = "SELECT nombre_servicio, costo_adicional FROM servicio_adicional";

            using (SqlConnection conexion = ObtenerConexion())
            {
                try
                {
                    conexion.Open();
                    using (SqlDataAdapter adaptador = new SqlDataAdapter(query, conexion))
                    {
                        adaptador.Fill(tabla);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Error al obtener los servicios: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }

            return tabla;
        }
        // Eliminar paquete por nombre
        public void EliminarPaquetePorNombre(string nombre)
        {
            using (SqlConnection conexion = ObtenerConexion())
            {
                conexion.Open();
                string query = "DELETE FROM Paquete WHERE nombre_paquete = @nombre";
                using (SqlCommand cmd = new SqlCommand(query, conexion))
                {
                    cmd.Parameters.AddWithValue("@nombre", nombre);
                    cmd.ExecuteNonQuery();
                }
            }
        }

        // Eliminar servicio adicional por nombre
        public void EliminarServicioAdicionalPorNombre(string nombre)
        {
            using (SqlConnection conexion = ObtenerConexion())
            {
                conexion.Open();
                string query = "DELETE FROM Servicio_Adicional WHERE nombre_servicio = @nombre";
                using (SqlCommand cmd = new SqlCommand(query, conexion))
                {
                    cmd.Parameters.AddWithValue("@nombre", nombre);
                    cmd.ExecuteNonQuery();
                }
            }
        }

    }


}





