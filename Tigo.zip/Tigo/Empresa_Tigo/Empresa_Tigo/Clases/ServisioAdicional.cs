﻿ using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Empresa_Tigo.Clases
{
    public class ServicioAdicional
    {
        private int id_servicio_adicional;
        private string nombre;
        private decimal costo;

        public ServicioAdicional(int id_servicio_adicional,string nombre,decimal costo)
        {
            this.id_servicio_adicional = id_servicio_adicional;
            this.nombre = nombre;
            this.costo = costo;
        }

        public int IdServicioAdicional { get => id_servicio_adicional; set => id_servicio_adicional = value; }
        public string Nombre { get => nombre; set => nombre = value; }
        public decimal Costo { get => costo; set => costo = value; }
    }
}



