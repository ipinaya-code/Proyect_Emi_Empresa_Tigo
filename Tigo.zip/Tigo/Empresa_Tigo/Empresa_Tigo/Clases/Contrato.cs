﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Empresa_Tigo.Clases
{
    public class Contrato
    {
        private int id_contrato;
        private DateTime fecha_inicio;
        private DateTime fecha_fin;
        private bool estado;
        private int id_cliente;
        private int id_paquete;

        public Contrato(int id_contrato,DateTime fecha_inicio,DateTime fecha_fin,bool estado,int id_cliente,int id_paquete)
        {
            this.id_contrato = id_contrato;
            this.fecha_inicio = fecha_inicio;
            this.fecha_fin = fecha_fin;
            this.estado = estado;
            this.id_cliente = id_cliente;
            this.id_paquete = id_paquete;
        }

        public int IdContrato { get => id_contrato; set => id_contrato = value; }
        public DateTime FechaInicio { get => fecha_inicio; set => fecha_inicio = value; }
        public DateTime FechaFin { get => fecha_fin; set => fecha_fin = value; }
        public bool Estado { get => estado; set => estado = value; }
        public int IdCliente { get => id_cliente; set => id_cliente = value; }
        public int IdPaquete { get => id_paquete; set => id_paquete = value; }

    }
    
}