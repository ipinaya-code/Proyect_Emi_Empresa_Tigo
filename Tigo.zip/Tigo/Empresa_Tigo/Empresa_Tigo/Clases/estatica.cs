﻿using System;

namespace Empresa_Tigo.Clases
{
    public class estatica
    {
        public static BaseDatos BD_consultas = new BaseDatos();
    }
}