﻿using Empresa_Tigo.Clases;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Empresa_Tigo
{
    public partial class FormLoginCliente : Form
    {
        public FormLoginCliente()
        {
            InitializeComponent();
        }
        
        private void btnEntrar_Click(object sender, EventArgs e)
        {
            string login = txtLogin.Text;
            string password = txtPassword.Text;

            Cliente cliente = estatica.BD_consultas.BuscarPorLoginYPassword(login, password);

            if (cliente != null)
            {
                this.DialogResult = DialogResult.OK;
                this.Close();
            }
            else
            {
                MessageBox.Show("Login o Password incorrectos.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            FormCliente cliente = new FormCliente();
            cliente.Show();
            cliente.BringToFront();  // Lo lleva al frente
            this.Focus();
            this.Close();
            

        }
    }
}
