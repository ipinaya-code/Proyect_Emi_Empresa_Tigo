﻿namespace Empresa_Tigo
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.Panel_Menu = new System.Windows.Forms.Panel();
            this.panel_logo = new System.Windows.Forms.Panel();
            this.panelBar = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.panelDesck = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.iconPictureBox5 = new FontAwesome.Sharp.IconPictureBox();
            this.iconPictureBox4 = new FontAwesome.Sharp.IconPictureBox();
            this.iconPictureBox3 = new FontAwesome.Sharp.IconPictureBox();
            this.iconPictureBox2 = new FontAwesome.Sharp.IconPictureBox();
            this.iconPictureBox1 = new FontAwesome.Sharp.IconPictureBox();
            this.panelBorde = new System.Windows.Forms.Panel();
            this.btnMinimizar = new FontAwesome.Sharp.IconButton();
            this.btnMaximizar = new FontAwesome.Sharp.IconButton();
            this.btnCerrar = new FontAwesome.Sharp.IconButton();
            this.iconCurrentChildFo = new FontAwesome.Sharp.IconPictureBox();
            this.btnReducirPaquetes = new FontAwesome.Sharp.IconButton();
            this.btnUsuario = new FontAwesome.Sharp.IconButton();
            this.btnPaquetes = new FontAwesome.Sharp.IconButton();
            this.btnClienteRegistrado = new FontAwesome.Sharp.IconButton();
            this.btnNuevoCliente = new FontAwesome.Sharp.IconButton();
            this.btnHome = new System.Windows.Forms.PictureBox();
            this.Panel_Menu.SuspendLayout();
            this.panel_logo.SuspendLayout();
            this.panelBar.SuspendLayout();
            this.panelDesck.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.iconPictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.iconPictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.iconPictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.iconPictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.iconPictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.iconCurrentChildFo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnHome)).BeginInit();
            this.SuspendLayout();
            // 
            // Panel_Menu
            // 
            this.Panel_Menu.BackColor = System.Drawing.Color.MidnightBlue;
            this.Panel_Menu.Controls.Add(this.btnReducirPaquetes);
            this.Panel_Menu.Controls.Add(this.btnUsuario);
            this.Panel_Menu.Controls.Add(this.btnPaquetes);
            this.Panel_Menu.Controls.Add(this.btnClienteRegistrado);
            this.Panel_Menu.Controls.Add(this.btnNuevoCliente);
            this.Panel_Menu.Controls.Add(this.panel_logo);
            this.Panel_Menu.Dock = System.Windows.Forms.DockStyle.Left;
            this.Panel_Menu.Location = new System.Drawing.Point(0, 0);
            this.Panel_Menu.Name = "Panel_Menu";
            this.Panel_Menu.Size = new System.Drawing.Size(387, 944);
            this.Panel_Menu.TabIndex = 0;
            // 
            // panel_logo
            // 
            this.panel_logo.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panel_logo.Controls.Add(this.btnHome);
            this.panel_logo.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel_logo.Location = new System.Drawing.Point(0, 0);
            this.panel_logo.Name = "panel_logo";
            this.panel_logo.Size = new System.Drawing.Size(387, 263);
            this.panel_logo.TabIndex = 0;
            // 
            // panelBar
            // 
            this.panelBar.BackColor = System.Drawing.Color.MidnightBlue;
            this.panelBar.Controls.Add(this.btnMinimizar);
            this.panelBar.Controls.Add(this.btnMaximizar);
            this.panelBar.Controls.Add(this.btnCerrar);
            this.panelBar.Controls.Add(this.label1);
            this.panelBar.Controls.Add(this.iconCurrentChildFo);
            this.panelBar.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelBar.Location = new System.Drawing.Point(387, 0);
            this.panelBar.Name = "panelBar";
            this.panelBar.Size = new System.Drawing.Size(1232, 122);
            this.panelBar.TabIndex = 1;
            this.panelBar.MouseDown += new System.Windows.Forms.MouseEventHandler(this.panelBar_MouseDown);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Sitka Display", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(68, 58);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(138, 40);
            this.label1.TabIndex = 1;
            this.label1.Text = "Estas aqui";
            // 
            // panelDesck
            // 
            this.panelDesck.BackColor = System.Drawing.Color.RoyalBlue;
            this.panelDesck.Controls.Add(this.label3);
            this.panelDesck.Controls.Add(this.iconPictureBox5);
            this.panelDesck.Controls.Add(this.iconPictureBox4);
            this.panelDesck.Controls.Add(this.label2);
            this.panelDesck.Controls.Add(this.iconPictureBox3);
            this.panelDesck.Controls.Add(this.iconPictureBox2);
            this.panelDesck.Controls.Add(this.iconPictureBox1);
            this.panelDesck.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelDesck.Location = new System.Drawing.Point(387, 257);
            this.panelDesck.Name = "panelDesck";
            this.panelDesck.Size = new System.Drawing.Size(1232, 687);
            this.panelDesck.TabIndex = 3;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Lucida Sans", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(6, 584);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(208, 27);
            this.label2.TabIndex = 3;
            this.label2.Text = "CONTACTANOS:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Stencil", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(315, 41);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(568, 38);
            this.label3.TabIndex = 6;
            this.label3.Text = "Tigo una empresa 100% Boliviana";
            // 
            // iconPictureBox5
            // 
            this.iconPictureBox5.BackColor = System.Drawing.Color.RoyalBlue;
            this.iconPictureBox5.BackgroundImage = global::Empresa_Tigo.Properties.Resources.fon1;
            this.iconPictureBox5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.iconPictureBox5.ForeColor = System.Drawing.SystemColors.ControlText;
            this.iconPictureBox5.IconChar = FontAwesome.Sharp.IconChar.None;
            this.iconPictureBox5.IconColor = System.Drawing.SystemColors.ControlText;
            this.iconPictureBox5.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconPictureBox5.IconSize = 226;
            this.iconPictureBox5.Location = new System.Drawing.Point(243, 353);
            this.iconPictureBox5.Name = "iconPictureBox5";
            this.iconPictureBox5.Size = new System.Drawing.Size(731, 226);
            this.iconPictureBox5.TabIndex = 5;
            this.iconPictureBox5.TabStop = false;
            // 
            // iconPictureBox4
            // 
            this.iconPictureBox4.BackColor = System.Drawing.Color.RoyalBlue;
            this.iconPictureBox4.BackgroundImage = global::Empresa_Tigo.Properties.Resources.fon2;
            this.iconPictureBox4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.iconPictureBox4.ForeColor = System.Drawing.SystemColors.ControlText;
            this.iconPictureBox4.IconChar = FontAwesome.Sharp.IconChar.None;
            this.iconPictureBox4.IconColor = System.Drawing.SystemColors.ControlText;
            this.iconPictureBox4.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconPictureBox4.IconSize = 238;
            this.iconPictureBox4.Location = new System.Drawing.Point(243, 105);
            this.iconPictureBox4.Name = "iconPictureBox4";
            this.iconPictureBox4.Size = new System.Drawing.Size(731, 238);
            this.iconPictureBox4.TabIndex = 4;
            this.iconPictureBox4.TabStop = false;
            // 
            // iconPictureBox3
            // 
            this.iconPictureBox3.BackColor = System.Drawing.Color.White;
            this.iconPictureBox3.ForeColor = System.Drawing.Color.Blue;
            this.iconPictureBox3.IconChar = FontAwesome.Sharp.IconChar.Facebook;
            this.iconPictureBox3.IconColor = System.Drawing.Color.Blue;
            this.iconPictureBox3.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconPictureBox3.IconSize = 51;
            this.iconPictureBox3.Location = new System.Drawing.Point(17, 614);
            this.iconPictureBox3.Name = "iconPictureBox3";
            this.iconPictureBox3.Size = new System.Drawing.Size(51, 51);
            this.iconPictureBox3.TabIndex = 2;
            this.iconPictureBox3.TabStop = false;
            // 
            // iconPictureBox2
            // 
            this.iconPictureBox2.BackColor = System.Drawing.Color.White;
            this.iconPictureBox2.ForeColor = System.Drawing.Color.Orange;
            this.iconPictureBox2.IconChar = FontAwesome.Sharp.IconChar.Google;
            this.iconPictureBox2.IconColor = System.Drawing.Color.Orange;
            this.iconPictureBox2.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconPictureBox2.IconSize = 51;
            this.iconPictureBox2.Location = new System.Drawing.Point(75, 614);
            this.iconPictureBox2.Name = "iconPictureBox2";
            this.iconPictureBox2.Size = new System.Drawing.Size(51, 51);
            this.iconPictureBox2.TabIndex = 1;
            this.iconPictureBox2.TabStop = false;
            // 
            // iconPictureBox1
            // 
            this.iconPictureBox1.BackColor = System.Drawing.Color.Lime;
            this.iconPictureBox1.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.iconPictureBox1.IconChar = FontAwesome.Sharp.IconChar.Whatsapp;
            this.iconPictureBox1.IconColor = System.Drawing.SystemColors.ControlLight;
            this.iconPictureBox1.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconPictureBox1.IconSize = 51;
            this.iconPictureBox1.Location = new System.Drawing.Point(132, 614);
            this.iconPictureBox1.Name = "iconPictureBox1";
            this.iconPictureBox1.Size = new System.Drawing.Size(51, 51);
            this.iconPictureBox1.TabIndex = 0;
            this.iconPictureBox1.TabStop = false;
            // 
            // panelBorde
            // 
            this.panelBorde.BackgroundImage = global::Empresa_Tigo.Properties.Resources.borde;
            this.panelBorde.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panelBorde.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelBorde.Location = new System.Drawing.Point(387, 122);
            this.panelBorde.Name = "panelBorde";
            this.panelBorde.Size = new System.Drawing.Size(1232, 135);
            this.panelBorde.TabIndex = 2;
            // 
            // btnMinimizar
            // 
            this.btnMinimizar.BackColor = System.Drawing.Color.MidnightBlue;
            this.btnMinimizar.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnMinimizar.IconChar = FontAwesome.Sharp.IconChar.Minus;
            this.btnMinimizar.IconColor = System.Drawing.Color.White;
            this.btnMinimizar.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.btnMinimizar.Location = new System.Drawing.Point(1028, 12);
            this.btnMinimizar.Name = "btnMinimizar";
            this.btnMinimizar.Size = new System.Drawing.Size(60, 57);
            this.btnMinimizar.TabIndex = 3;
            this.btnMinimizar.UseVisualStyleBackColor = false;
            this.btnMinimizar.Click += new System.EventHandler(this.btnMinimizar_Click);
            // 
            // btnMaximizar
            // 
            this.btnMaximizar.BackColor = System.Drawing.Color.MidnightBlue;
            this.btnMaximizar.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnMaximizar.IconChar = FontAwesome.Sharp.IconChar.Maximize;
            this.btnMaximizar.IconColor = System.Drawing.Color.White;
            this.btnMaximizar.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.btnMaximizar.Location = new System.Drawing.Point(1094, 12);
            this.btnMaximizar.Name = "btnMaximizar";
            this.btnMaximizar.Size = new System.Drawing.Size(60, 57);
            this.btnMaximizar.TabIndex = 2;
            this.btnMaximizar.UseVisualStyleBackColor = false;
            this.btnMaximizar.Click += new System.EventHandler(this.btnMaximizar_Click);
            // 
            // btnCerrar
            // 
            this.btnCerrar.BackColor = System.Drawing.Color.MidnightBlue;
            this.btnCerrar.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnCerrar.IconChar = FontAwesome.Sharp.IconChar.X;
            this.btnCerrar.IconColor = System.Drawing.Color.White;
            this.btnCerrar.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.btnCerrar.Location = new System.Drawing.Point(1160, 12);
            this.btnCerrar.Name = "btnCerrar";
            this.btnCerrar.Size = new System.Drawing.Size(60, 57);
            this.btnCerrar.TabIndex = 0;
            this.btnCerrar.UseVisualStyleBackColor = false;
            this.btnCerrar.Click += new System.EventHandler(this.btnCerrar_Click);
            // 
            // iconCurrentChildFo
            // 
            this.iconCurrentChildFo.BackColor = System.Drawing.Color.MidnightBlue;
            this.iconCurrentChildFo.IconChar = FontAwesome.Sharp.IconChar.HomeLg;
            this.iconCurrentChildFo.IconColor = System.Drawing.Color.White;
            this.iconCurrentChildFo.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconCurrentChildFo.IconSize = 52;
            this.iconCurrentChildFo.Location = new System.Drawing.Point(17, 55);
            this.iconCurrentChildFo.Name = "iconCurrentChildFo";
            this.iconCurrentChildFo.Size = new System.Drawing.Size(67, 52);
            this.iconCurrentChildFo.TabIndex = 0;
            this.iconCurrentChildFo.TabStop = false;
            // 
            // btnReducirPaquetes
            // 
            this.btnReducirPaquetes.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnReducirPaquetes.FlatAppearance.BorderSize = 0;
            this.btnReducirPaquetes.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnReducirPaquetes.Font = new System.Drawing.Font("PMingLiU-ExtB", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnReducirPaquetes.ForeColor = System.Drawing.Color.White;
            this.btnReducirPaquetes.IconChar = FontAwesome.Sharp.IconChar.PersonCircleMinus;
            this.btnReducirPaquetes.IconColor = System.Drawing.Color.White;
            this.btnReducirPaquetes.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.btnReducirPaquetes.IconSize = 60;
            this.btnReducirPaquetes.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnReducirPaquetes.Location = new System.Drawing.Point(0, 482);
            this.btnReducirPaquetes.Name = "btnReducirPaquetes";
            this.btnReducirPaquetes.Padding = new System.Windows.Forms.Padding(10, 0, 20, 0);
            this.btnReducirPaquetes.Size = new System.Drawing.Size(387, 73);
            this.btnReducirPaquetes.TabIndex = 5;
            this.btnReducirPaquetes.Text = "Cancelar Paquetes Tigo";
            this.btnReducirPaquetes.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnReducirPaquetes.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnReducirPaquetes.UseVisualStyleBackColor = true;
            this.btnReducirPaquetes.Click += new System.EventHandler(this.btnReducirPaquetes_Click);
            // 
            // btnUsuario
            // 
            this.btnUsuario.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.btnUsuario.FlatAppearance.BorderSize = 0;
            this.btnUsuario.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnUsuario.Font = new System.Drawing.Font("PMingLiU-ExtB", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnUsuario.ForeColor = System.Drawing.Color.White;
            this.btnUsuario.IconChar = FontAwesome.Sharp.IconChar.User;
            this.btnUsuario.IconColor = System.Drawing.Color.White;
            this.btnUsuario.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.btnUsuario.IconSize = 60;
            this.btnUsuario.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnUsuario.Location = new System.Drawing.Point(0, 871);
            this.btnUsuario.Name = "btnUsuario";
            this.btnUsuario.Padding = new System.Windows.Forms.Padding(10, 0, 20, 0);
            this.btnUsuario.Size = new System.Drawing.Size(387, 73);
            this.btnUsuario.TabIndex = 4;
            this.btnUsuario.Text = "Administrador";
            this.btnUsuario.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnUsuario.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnUsuario.UseVisualStyleBackColor = true;
            this.btnUsuario.Click += new System.EventHandler(this.btnUsuario_Click);
            // 
            // btnPaquetes
            // 
            this.btnPaquetes.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnPaquetes.FlatAppearance.BorderSize = 0;
            this.btnPaquetes.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnPaquetes.Font = new System.Drawing.Font("PMingLiU-ExtB", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPaquetes.ForeColor = System.Drawing.Color.White;
            this.btnPaquetes.IconChar = FontAwesome.Sharp.IconChar.Pager;
            this.btnPaquetes.IconColor = System.Drawing.Color.White;
            this.btnPaquetes.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.btnPaquetes.IconSize = 60;
            this.btnPaquetes.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnPaquetes.Location = new System.Drawing.Point(0, 409);
            this.btnPaquetes.Name = "btnPaquetes";
            this.btnPaquetes.Padding = new System.Windows.Forms.Padding(10, 0, 20, 0);
            this.btnPaquetes.Size = new System.Drawing.Size(387, 73);
            this.btnPaquetes.TabIndex = 3;
            this.btnPaquetes.Text = "Paquetes Tigo";
            this.btnPaquetes.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnPaquetes.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnPaquetes.UseVisualStyleBackColor = true;
            this.btnPaquetes.Click += new System.EventHandler(this.btnPaquetes_Click);
            // 
            // btnClienteRegistrado
            // 
            this.btnClienteRegistrado.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnClienteRegistrado.FlatAppearance.BorderSize = 0;
            this.btnClienteRegistrado.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnClienteRegistrado.Font = new System.Drawing.Font("PMingLiU-ExtB", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClienteRegistrado.ForeColor = System.Drawing.Color.White;
            this.btnClienteRegistrado.IconChar = FontAwesome.Sharp.IconChar.PersonCircleCheck;
            this.btnClienteRegistrado.IconColor = System.Drawing.Color.White;
            this.btnClienteRegistrado.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.btnClienteRegistrado.IconSize = 60;
            this.btnClienteRegistrado.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnClienteRegistrado.Location = new System.Drawing.Point(0, 336);
            this.btnClienteRegistrado.Name = "btnClienteRegistrado";
            this.btnClienteRegistrado.Padding = new System.Windows.Forms.Padding(10, 0, 20, 0);
            this.btnClienteRegistrado.Size = new System.Drawing.Size(387, 73);
            this.btnClienteRegistrado.TabIndex = 2;
            this.btnClienteRegistrado.Text = "Cliente Registrado";
            this.btnClienteRegistrado.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnClienteRegistrado.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnClienteRegistrado.UseVisualStyleBackColor = true;
            this.btnClienteRegistrado.Click += new System.EventHandler(this.btnClienteRegistrado_Click);
            // 
            // btnNuevoCliente
            // 
            this.btnNuevoCliente.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnNuevoCliente.FlatAppearance.BorderSize = 0;
            this.btnNuevoCliente.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnNuevoCliente.Font = new System.Drawing.Font("PMingLiU-ExtB", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNuevoCliente.ForeColor = System.Drawing.Color.White;
            this.btnNuevoCliente.IconChar = FontAwesome.Sharp.IconChar.PersonCircleExclamation;
            this.btnNuevoCliente.IconColor = System.Drawing.Color.White;
            this.btnNuevoCliente.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.btnNuevoCliente.IconSize = 60;
            this.btnNuevoCliente.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnNuevoCliente.Location = new System.Drawing.Point(0, 263);
            this.btnNuevoCliente.Name = "btnNuevoCliente";
            this.btnNuevoCliente.Padding = new System.Windows.Forms.Padding(10, 0, 20, 0);
            this.btnNuevoCliente.Size = new System.Drawing.Size(387, 73);
            this.btnNuevoCliente.TabIndex = 1;
            this.btnNuevoCliente.Text = "Nuevo Cliente (Registrarse)";
            this.btnNuevoCliente.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnNuevoCliente.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnNuevoCliente.UseVisualStyleBackColor = true;
            this.btnNuevoCliente.Click += new System.EventHandler(this.btnNuevoCliente_Click);
            // 
            // btnHome
            // 
            this.btnHome.Image = global::Empresa_Tigo.Properties.Resources.tigo;
            this.btnHome.Location = new System.Drawing.Point(3, 3);
            this.btnHome.Name = "btnHome";
            this.btnHome.Size = new System.Drawing.Size(381, 254);
            this.btnHome.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.btnHome.TabIndex = 0;
            this.btnHome.TabStop = false;
            this.btnHome.Click += new System.EventHandler(this.btnHome_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1619, 944);
            this.Controls.Add(this.panelDesck);
            this.Controls.Add(this.panelBorde);
            this.Controls.Add(this.panelBar);
            this.Controls.Add(this.Panel_Menu);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Form1";
            this.Text = "Form1";
            this.Panel_Menu.ResumeLayout(false);
            this.panel_logo.ResumeLayout(false);
            this.panelBar.ResumeLayout(false);
            this.panelBar.PerformLayout();
            this.panelDesck.ResumeLayout(false);
            this.panelDesck.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.iconPictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.iconPictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.iconPictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.iconPictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.iconPictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.iconCurrentChildFo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnHome)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel Panel_Menu;
        private FontAwesome.Sharp.IconButton btnNuevoCliente;
        private FontAwesome.Sharp.IconButton btnUsuario;
        private FontAwesome.Sharp.IconButton btnPaquetes;
        private FontAwesome.Sharp.IconButton btnClienteRegistrado;
        private FontAwesome.Sharp.IconButton btnReducirPaquetes;
        private System.Windows.Forms.Panel panel_logo;
        private System.Windows.Forms.PictureBox btnHome;
        private System.Windows.Forms.Panel panelBar;
        private FontAwesome.Sharp.IconPictureBox iconCurrentChildFo;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panelBorde;
        private System.Windows.Forms.Panel panelDesck;
        private FontAwesome.Sharp.IconButton btnCerrar;
        private FontAwesome.Sharp.IconButton btnMinimizar;
        private FontAwesome.Sharp.IconButton btnMaximizar;
        private FontAwesome.Sharp.IconPictureBox iconPictureBox1;
        private System.Windows.Forms.Label label2;
        private FontAwesome.Sharp.IconPictureBox iconPictureBox3;
        private FontAwesome.Sharp.IconPictureBox iconPictureBox2;
        private FontAwesome.Sharp.IconPictureBox iconPictureBox4;
        private FontAwesome.Sharp.IconPictureBox iconPictureBox5;
        private System.Windows.Forms.Label label3;
    }
}

