﻿namespace Empresa_Tigo.form
{
    partial class FormReducir
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label2 = new System.Windows.Forms.Label();
            this.btnPaqueteNormal = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.btnPaqueteExtra = new System.Windows.Forms.Button();
            this.btnEliminar = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Palatino Linotype", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(386, 39);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(413, 38);
            this.label2.TabIndex = 2;
            this.label2.Text = "MODIFICAR SUS PAQUETES";
            // 
            // btnPaqueteNormal
            // 
            this.btnPaqueteNormal.Location = new System.Drawing.Point(36, 110);
            this.btnPaqueteNormal.Name = "btnPaqueteNormal";
            this.btnPaqueteNormal.Size = new System.Drawing.Size(179, 86);
            this.btnPaqueteNormal.TabIndex = 3;
            this.btnPaqueteNormal.Text = "PAQUETES NORMALES";
            this.btnPaqueteNormal.UseVisualStyleBackColor = true;
            this.btnPaqueteNormal.Click += new System.EventHandler(this.btnPaqueteNormal_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(300, 110);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 62;
            this.dataGridView1.RowTemplate.Height = 28;
            this.dataGridView1.Size = new System.Drawing.Size(747, 480);
            this.dataGridView1.TabIndex = 5;
            // 
            // btnPaqueteExtra
            // 
            this.btnPaqueteExtra.Location = new System.Drawing.Point(36, 218);
            this.btnPaqueteExtra.Name = "btnPaqueteExtra";
            this.btnPaqueteExtra.Size = new System.Drawing.Size(179, 84);
            this.btnPaqueteExtra.TabIndex = 6;
            this.btnPaqueteExtra.Text = "PAQUETES EXTRAS";
            this.btnPaqueteExtra.UseVisualStyleBackColor = true;
            this.btnPaqueteExtra.Click += new System.EventHandler(this.btnPaqueteExtra_Click);
            // 
            // btnEliminar
            // 
            this.btnEliminar.Location = new System.Drawing.Point(36, 542);
            this.btnEliminar.Name = "btnEliminar";
            this.btnEliminar.Size = new System.Drawing.Size(179, 48);
            this.btnEliminar.TabIndex = 7;
            this.btnEliminar.Text = "ELIMINAR PAQUETE";
            this.btnEliminar.UseVisualStyleBackColor = true;
            this.btnEliminar.Click += new System.EventHandler(this.btnEliminar_Click);
            // 
            // FormReducir
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.RoyalBlue;
            this.ClientSize = new System.Drawing.Size(1210, 631);
            this.Controls.Add(this.btnEliminar);
            this.Controls.Add(this.btnPaqueteExtra);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.btnPaqueteNormal);
            this.Controls.Add(this.label2);
            this.Name = "FormReducir";
            this.Text = "FormReducir";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnPaqueteNormal;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button btnPaqueteExtra;
        private System.Windows.Forms.Button btnEliminar;
    }
}