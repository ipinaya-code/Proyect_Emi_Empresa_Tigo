﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Empresa_Tigo.form
{
    public partial class FormPaquetes : Form
    {
        public FormPaquetes()
        {
            InitializeComponent();
        }
        /*/private void OcultarTodosLosGrupos()
        {
            grpTv_cable.Visible = false;
            grpWifi.Visible = false;
            grpMovil.Visible = false;
        }/*/
        private void iconPictureBoxTv_Cable_Click(object sender, EventArgs e)
        {
           // OcultarTodosLosGrupos();
            grpTv_cable.Visible = true;
            grpWifi.Visible = false;
            grpMovil.Visible = false;
        }

        private void iconPictureBoxWifi_Click(object sender, EventArgs e)
        {
            //OcultarTodosLosGrupos();
            grpWifi.Visible = true;
            grpTv_cable.Visible = false;
            grpMovil.Visible = false;
        }

        private void iconPictureBoxMegas_Click(object sender, EventArgs e)
        {
            //OcultarTodosLosGrupos();
            grpMovil.Visible = true;
            grpTv_cable.Visible = false;
            grpWifi.Visible = false;
        }

        private void btnAceptarCable_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Debes registrarte para comprar, o ingresa con tu cuenta de cliente.", "Información", MessageBoxButtons.OK, MessageBoxIcon.Information);
            
        }

        private void btnAceptarRed_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Debes registrarte para comprar, o ingresa con tu cuenta de cliente.", "Información", MessageBoxButtons.OK, MessageBoxIcon.Information);
            
        }

        private void btnAceptarMegas_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Debes registrarte para comprar, o ingresa con tu cuenta de cliente.", "Información", MessageBoxButtons.OK, MessageBoxIcon.Information);
           
        }

        private void btnCancelar_Extra_Click(object sender, EventArgs e)
        {
            grpExtra.Visible = false;
        }

        private void grpMovil_Enter(object sender, EventArgs e)
        {
            /*switch (cmbMegas.SelectedItem.ToString())
            {
                case "50 mbps":
                    txtPrecioMegas.Text = "120";
                    break;
                case "100 mbps":
                    txtPrecioMegas.Text = "150";
                    break;
                case "200 mbps":
                    txtPrecioMegas.Text = "200";
                    break;
                case "300 mbps":
                    txtPrecioMegas.Text = "250";
                    break;
            }*/
        }

        private void grpWifi_Enter(object sender, EventArgs e)
        {
            /*switch (cmbRed.SelectedItem.ToString())
            {
                case "100 megas":
                    txtPrecioRed.Text = "120";
                    break;
                case "150 megas":
                    txtPrecioRed.Text = "150";
                    break;
                case "200 megas":
                    txtPrecioRed.Text = "200";
                    break;
                case "250 megas":
                    txtPrecioRed.Text = "250";
                    break;
            }*/
        }

        private void grpTv_cable_Enter(object sender, EventArgs e)
        {
            
        }
        private string servicioSeleccionado = "";
        private void btnDisney_Click(object sender, EventArgs e)
        {
            servicioSeleccionado = "Disney";
            txtPlanExtra.Text = "30";
        }

        private void btnHbo_Click(object sender, EventArgs e)
        {
            servicioSeleccionado = "HBO";
            txtPlanExtra.Text = "40";
        }

        private void btnPara_Click(object sender, EventArgs e)
        {
            servicioSeleccionado = "Paramount";
            txtPlanExtra.Text = "35";
        }

        private void btnAceptar_Extra_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Debes registrarte para comprar, o ingresa con tu cuenta de cliente.", "Información", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void cmbRed_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmbRed.SelectedItem == null) return;
            var texto = cmbRed.SelectedItem.ToString();
            if (texto == "100megas")
            {
                txtPrecioRed.Text = "120";
            }
            if (texto == "150megas")
            {
                txtPrecioRed.Text = "150";
            }

            if (texto == "200megas")
            {
                txtPrecioRed.Text = "200";
            }
            if (texto == "250megas")
            {
                txtPrecioRed.Text = "250";
            }
            
        }

        private void cmbMegas_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmbMegas.SelectedItem == null) return;
            var texto = cmbMegas.SelectedItem.ToString();
            if (texto == "300mbps")
            {
                txtPrecioMegas.Text = "250";
            }
            if (texto == "150mbps")
            {
                txtPrecioMegas.Text = "150";
            }

            if (texto == "100mbps")
            {
                txtPrecioMegas.Text = "200";
            }
            if (texto == "200mbps")
            {
                txtPrecioMegas.Text = "350";
            }
            
        }

        private void cmbCanales_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmbCanales.SelectedItem == null) return;
            var texto = cmbCanales.SelectedItem.ToString();
            if (texto == "150canales")
            {
                txtPrecioCanales.Text = "120";
            }
            if (texto == "200canales")
            {
                txtPrecioCanales.Text = "150";
            }

            if (texto == "250canales")
            {
                txtPrecioCanales.Text = "200";
            }
            if (texto == "300canales")
            {
                txtPrecioCanales.Text = "250";
            }
        }
    }
}
