﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Empresa_Tigo.form
{
    public partial class FormAdmi : Form
    {
        public FormAdmi()
        {
            InitializeComponent();
        }
        private void CargarDatos(string query)
        {
            try
            {
                using (SqlConnection conexion = new SqlConnection(@"Data Source=DESKTOP-PAGR342\SQLEXPRESS;Initial Catalog=bd_Tigo;Integrated Security=True;Encrypt=False"))
                {
                    conexion.Open();
                    SqlDataAdapter adaptador = new SqlDataAdapter(query, conexion);
                    DataTable tabla = new DataTable();
                    adaptador.Fill(tabla);

                    dataGridView1.DataSource = tabla;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al cargar datos: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // BOTÓN: Mostrar tabla Cliente
        private void btnMostrarClientes_Click(object sender, EventArgs e)
        {
            string query = "SELECT * FROM Cliente";
            CargarDatos(query);
        }

        // BOTÓN: Mostrar tabla Pago
        private void btnMostrarPago_Click(object sender, EventArgs e)
        {
            string query = "SELECT * FROM Pago";
            CargarDatos(query);
        }

        // BOTÓN: Mostrar tabla Contrato
        private void btnMostrarContratos_Click(object sender, EventArgs e)
        {
            string query = "SELECT * FROM Contrato";
            CargarDatos(query);
        }

        // BOTÓN: Mostrar tabla Paquete
        private void btnMostrarPaquetes_Click(object sender, EventArgs e)
        {
            string query = "SELECT * FROM Paquete";
            CargarDatos(query);
        }

        // BOTÓN: Mostrar tabla Servicio_Adicional
        private void btnMostrarS_Adicional_Click(object sender, EventArgs e)
        {
            string query = "SELECT * FROM Servicio_Adicional";
            CargarDatos(query);
        }

        // BOTÓN: Mostrar tabla Contratar_Adicional
        private void btnMostrarC_Adicional_Click(object sender, EventArgs e)
        {
            string query = "SELECT * FROM Contrato_Servicio_Adicional";
            CargarDatos(query);
        }

    }
}
