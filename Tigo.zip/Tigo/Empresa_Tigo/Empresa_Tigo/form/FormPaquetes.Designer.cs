﻿namespace Empresa_Tigo.form
{
    partial class FormPaquetes
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.grpExtra = new System.Windows.Forms.GroupBox();
            this.txtPlanExtra = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.grpMovil = new System.Windows.Forms.GroupBox();
            this.txtPrecioMegas = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.cmbMegas = new System.Windows.Forms.ComboBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.grpTv_cable = new System.Windows.Forms.GroupBox();
            this.grpWifi = new System.Windows.Forms.GroupBox();
            this.txtPrecioRed = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.cmbRed = new System.Windows.Forms.ComboBox();
            this.txtPrecioCanales = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.cmbCanales = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.btnCancelar_Extra = new FontAwesome.Sharp.IconButton();
            this.btnAceptar_Extra = new FontAwesome.Sharp.IconButton();
            this.btnPara = new FontAwesome.Sharp.IconPictureBox();
            this.btnHbo = new FontAwesome.Sharp.IconPictureBox();
            this.btnDisney = new FontAwesome.Sharp.IconPictureBox();
            this.btnAceptarRed = new FontAwesome.Sharp.IconButton();
            this.btnAceptarMegas = new FontAwesome.Sharp.IconButton();
            this.btnAceptarCable = new FontAwesome.Sharp.IconButton();
            this.iconPictureBoxMegas = new FontAwesome.Sharp.IconPictureBox();
            this.iconPictureBoxWifi = new FontAwesome.Sharp.IconPictureBox();
            this.iconPictureBoxTv_Cable = new FontAwesome.Sharp.IconPictureBox();
            this.grpExtra.SuspendLayout();
            this.grpMovil.SuspendLayout();
            this.grpTv_cable.SuspendLayout();
            this.grpWifi.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.btnPara)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnHbo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnDisney)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.iconPictureBoxMegas)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.iconPictureBoxWifi)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.iconPictureBoxTv_Cable)).BeginInit();
            this.SuspendLayout();
            // 
            // grpExtra
            // 
            this.grpExtra.Controls.Add(this.btnCancelar_Extra);
            this.grpExtra.Controls.Add(this.btnAceptar_Extra);
            this.grpExtra.Controls.Add(this.txtPlanExtra);
            this.grpExtra.Controls.Add(this.label12);
            this.grpExtra.Controls.Add(this.btnPara);
            this.grpExtra.Controls.Add(this.btnHbo);
            this.grpExtra.Controls.Add(this.btnDisney);
            this.grpExtra.Font = new System.Drawing.Font("MS Reference Sans Serif", 14F, System.Drawing.FontStyle.Bold);
            this.grpExtra.ForeColor = System.Drawing.Color.White;
            this.grpExtra.Location = new System.Drawing.Point(761, 101);
            this.grpExtra.Name = "grpExtra";
            this.grpExtra.Size = new System.Drawing.Size(380, 436);
            this.grpExtra.TabIndex = 21;
            this.grpExtra.TabStop = false;
            this.grpExtra.Text = "PAQUETE EXTRA";
            // 
            // txtPlanExtra
            // 
            this.txtPlanExtra.Location = new System.Drawing.Point(281, 281);
            this.txtPlanExtra.Name = "txtPlanExtra";
            this.txtPlanExtra.Size = new System.Drawing.Size(81, 42);
            this.txtPlanExtra.TabIndex = 12;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(25, 281);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(250, 35);
            this.label12.TabIndex = 12;
            this.label12.Text = "COSTO  1 MES:";
            // 
            // grpMovil
            // 
            this.grpMovil.Controls.Add(this.btnAceptarMegas);
            this.grpMovil.Controls.Add(this.txtPrecioMegas);
            this.grpMovil.Controls.Add(this.label10);
            this.grpMovil.Controls.Add(this.label11);
            this.grpMovil.Controls.Add(this.cmbMegas);
            this.grpMovil.Font = new System.Drawing.Font("MS Reference Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpMovil.ForeColor = System.Drawing.Color.White;
            this.grpMovil.Location = new System.Drawing.Point(214, 100);
            this.grpMovil.Name = "grpMovil";
            this.grpMovil.Size = new System.Drawing.Size(462, 261);
            this.grpMovil.TabIndex = 22;
            this.grpMovil.TabStop = false;
            this.grpMovil.Text = "MOVIL";
            this.grpMovil.Visible = false;
            this.grpMovil.Enter += new System.EventHandler(this.grpMovil_Enter);
            // 
            // txtPrecioMegas
            // 
            this.txtPrecioMegas.Location = new System.Drawing.Point(42, 190);
            this.txtPrecioMegas.Name = "txtPrecioMegas";
            this.txtPrecioMegas.Size = new System.Drawing.Size(85, 42);
            this.txtPrecioMegas.TabIndex = 9;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(36, 145);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(387, 35);
            this.label10.TabIndex = 8;
            this.label10.Text = "COSTO DE LO ELEGIDO:";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(36, 56);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(136, 35);
            this.label11.TabIndex = 7;
            this.label11.Text = "MEGAS:";
            // 
            // cmbMegas
            // 
            this.cmbMegas.FormattingEnabled = true;
            this.cmbMegas.Items.AddRange(new object[] {
            "50mbps",
            "100mbps",
            "200mbps",
            "300mbps"});
            this.cmbMegas.Location = new System.Drawing.Point(42, 97);
            this.cmbMegas.Name = "cmbMegas";
            this.cmbMegas.Size = new System.Drawing.Size(288, 43);
            this.cmbMegas.TabIndex = 6;
            this.cmbMegas.SelectedIndexChanged += new System.EventHandler(this.cmbMegas_SelectedIndexChanged);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft YaHei UI", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.White;
            this.label5.Location = new System.Drawing.Point(22, 364);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(186, 27);
            this.label5.TabIndex = 20;
            this.label5.Text = "MEGAS-CELULAR";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft YaHei UI", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(78, 188);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(59, 27);
            this.label4.TabIndex = 19;
            this.label4.Text = "WIFI";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft YaHei UI", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(57, 12);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(112, 27);
            this.label3.TabIndex = 18;
            this.label3.Text = "TV-CABLE";
            // 
            // grpTv_cable
            // 
            this.grpTv_cable.Controls.Add(this.btnAceptarCable);
            this.grpTv_cable.Controls.Add(this.txtPrecioCanales);
            this.grpTv_cable.Controls.Add(this.label7);
            this.grpTv_cable.Controls.Add(this.label6);
            this.grpTv_cable.Controls.Add(this.cmbCanales);
            this.grpTv_cable.Font = new System.Drawing.Font("MS Reference Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpTv_cable.ForeColor = System.Drawing.Color.White;
            this.grpTv_cable.Location = new System.Drawing.Point(214, 109);
            this.grpTv_cable.Name = "grpTv_cable";
            this.grpTv_cable.Size = new System.Drawing.Size(424, 299);
            this.grpTv_cable.TabIndex = 17;
            this.grpTv_cable.TabStop = false;
            this.grpTv_cable.Text = "Tv-cable";
            this.grpTv_cable.Visible = false;
            this.grpTv_cable.Enter += new System.EventHandler(this.grpTv_cable_Enter);
            // 
            // grpWifi
            // 
            this.grpWifi.Controls.Add(this.btnAceptarRed);
            this.grpWifi.Controls.Add(this.txtPrecioRed);
            this.grpWifi.Controls.Add(this.label8);
            this.grpWifi.Controls.Add(this.label9);
            this.grpWifi.Controls.Add(this.cmbRed);
            this.grpWifi.Font = new System.Drawing.Font("MS Reference Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpWifi.ForeColor = System.Drawing.Color.White;
            this.grpWifi.Location = new System.Drawing.Point(214, 276);
            this.grpWifi.Name = "grpWifi";
            this.grpWifi.Size = new System.Drawing.Size(462, 261);
            this.grpWifi.TabIndex = 8;
            this.grpWifi.TabStop = false;
            this.grpWifi.Text = "WIFI";
            this.grpWifi.Visible = false;
            this.grpWifi.Enter += new System.EventHandler(this.grpWifi_Enter);
            // 
            // txtPrecioRed
            // 
            this.txtPrecioRed.Location = new System.Drawing.Point(49, 195);
            this.txtPrecioRed.Name = "txtPrecioRed";
            this.txtPrecioRed.Size = new System.Drawing.Size(80, 42);
            this.txtPrecioRed.TabIndex = 9;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(38, 157);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(387, 35);
            this.label8.TabIndex = 8;
            this.label8.Text = "COSTO DE LO ELEGIDO:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(38, 56);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(91, 35);
            this.label9.TabIndex = 7;
            this.label9.Text = "RED:";
            // 
            // cmbRed
            // 
            this.cmbRed.FormattingEnabled = true;
            this.cmbRed.Items.AddRange(new object[] {
            "100megas",
            "150megas",
            "200 megas",
            "250 megas"});
            this.cmbRed.Location = new System.Drawing.Point(42, 97);
            this.cmbRed.Name = "cmbRed";
            this.cmbRed.Size = new System.Drawing.Size(288, 43);
            this.cmbRed.TabIndex = 6;
            this.cmbRed.SelectedIndexChanged += new System.EventHandler(this.cmbRed_SelectedIndexChanged);
            // 
            // txtPrecioCanales
            // 
            this.txtPrecioCanales.Location = new System.Drawing.Point(36, 183);
            this.txtPrecioCanales.Name = "txtPrecioCanales";
            this.txtPrecioCanales.Size = new System.Drawing.Size(145, 42);
            this.txtPrecioCanales.TabIndex = 3;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(16, 148);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(387, 35);
            this.label7.TabIndex = 2;
            this.label7.Text = "COSTO DE LO ELEGIDO:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(30, 61);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(168, 35);
            this.label6.TabIndex = 1;
            this.label6.Text = "CANALES:";
            // 
            // cmbCanales
            // 
            this.cmbCanales.FormattingEnabled = true;
            this.cmbCanales.Items.AddRange(new object[] {
            "150canales",
            "200canales",
            "250canales",
            "300canales"});
            this.cmbCanales.Location = new System.Drawing.Point(34, 102);
            this.cmbCanales.Name = "cmbCanales";
            this.cmbCanales.Size = new System.Drawing.Size(288, 43);
            this.cmbCanales.TabIndex = 0;
            this.cmbCanales.SelectedIndexChanged += new System.EventHandler(this.cmbCanales_SelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Palatino Linotype", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(341, 31);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(432, 38);
            this.label1.TabIndex = 13;
            this.label1.Text = "TE OFRECE ESTOS PAQUETES";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Palatino Linotype", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(418, 64);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(199, 38);
            this.label2.TabIndex = 12;
            this.label2.Text = "SELECCIONE";
            // 
            // btnCancelar_Extra
            // 
            this.btnCancelar_Extra.ForeColor = System.Drawing.Color.Black;
            this.btnCancelar_Extra.IconChar = FontAwesome.Sharp.IconChar.X;
            this.btnCancelar_Extra.IconColor = System.Drawing.Color.Black;
            this.btnCancelar_Extra.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.btnCancelar_Extra.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnCancelar_Extra.Location = new System.Drawing.Point(75, 378);
            this.btnCancelar_Extra.Name = "btnCancelar_Extra";
            this.btnCancelar_Extra.Size = new System.Drawing.Size(243, 43);
            this.btnCancelar_Extra.TabIndex = 12;
            this.btnCancelar_Extra.Text = "CANCELAR";
            this.btnCancelar_Extra.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnCancelar_Extra.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnCancelar_Extra.UseVisualStyleBackColor = true;
            this.btnCancelar_Extra.Click += new System.EventHandler(this.btnCancelar_Extra_Click);
            // 
            // btnAceptar_Extra
            // 
            this.btnAceptar_Extra.ForeColor = System.Drawing.Color.Black;
            this.btnAceptar_Extra.IconChar = FontAwesome.Sharp.IconChar.Check;
            this.btnAceptar_Extra.IconColor = System.Drawing.Color.Black;
            this.btnAceptar_Extra.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.btnAceptar_Extra.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnAceptar_Extra.Location = new System.Drawing.Point(75, 329);
            this.btnAceptar_Extra.Name = "btnAceptar_Extra";
            this.btnAceptar_Extra.Size = new System.Drawing.Size(243, 43);
            this.btnAceptar_Extra.TabIndex = 12;
            this.btnAceptar_Extra.Text = "ACEPTAR";
            this.btnAceptar_Extra.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnAceptar_Extra.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnAceptar_Extra.UseVisualStyleBackColor = true;
            this.btnAceptar_Extra.Click += new System.EventHandler(this.btnAceptar_Extra_Click);
            // 
            // btnPara
            // 
            this.btnPara.BackColor = System.Drawing.Color.RoyalBlue;
            this.btnPara.BackgroundImage = global::Empresa_Tigo.Properties.Resources.paraumt;
            this.btnPara.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnPara.IconChar = FontAwesome.Sharp.IconChar.None;
            this.btnPara.IconColor = System.Drawing.Color.White;
            this.btnPara.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.btnPara.IconSize = 87;
            this.btnPara.Location = new System.Drawing.Point(126, 175);
            this.btnPara.Name = "btnPara";
            this.btnPara.Size = new System.Drawing.Size(135, 87);
            this.btnPara.TabIndex = 2;
            this.btnPara.TabStop = false;
            this.btnPara.Click += new System.EventHandler(this.btnPara_Click);
            // 
            // btnHbo
            // 
            this.btnHbo.BackColor = System.Drawing.Color.RoyalBlue;
            this.btnHbo.BackgroundImage = global::Empresa_Tigo.Properties.Resources.hbo_max;
            this.btnHbo.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnHbo.IconChar = FontAwesome.Sharp.IconChar.None;
            this.btnHbo.IconColor = System.Drawing.Color.White;
            this.btnHbo.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.btnHbo.IconSize = 87;
            this.btnHbo.Location = new System.Drawing.Point(212, 70);
            this.btnHbo.Name = "btnHbo";
            this.btnHbo.Size = new System.Drawing.Size(135, 87);
            this.btnHbo.TabIndex = 1;
            this.btnHbo.TabStop = false;
            this.btnHbo.Click += new System.EventHandler(this.btnHbo_Click);
            // 
            // btnDisney
            // 
            this.btnDisney.BackColor = System.Drawing.Color.RoyalBlue;
            this.btnDisney.BackgroundImage = global::Empresa_Tigo.Properties.Resources.disney;
            this.btnDisney.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnDisney.IconChar = FontAwesome.Sharp.IconChar.None;
            this.btnDisney.IconColor = System.Drawing.Color.White;
            this.btnDisney.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.btnDisney.IconSize = 87;
            this.btnDisney.Location = new System.Drawing.Point(31, 70);
            this.btnDisney.Name = "btnDisney";
            this.btnDisney.Size = new System.Drawing.Size(135, 87);
            this.btnDisney.TabIndex = 0;
            this.btnDisney.TabStop = false;
            this.btnDisney.Click += new System.EventHandler(this.btnDisney_Click);
            // 
            // btnAceptarRed
            // 
            this.btnAceptarRed.ForeColor = System.Drawing.Color.Black;
            this.btnAceptarRed.IconChar = FontAwesome.Sharp.IconChar.Check;
            this.btnAceptarRed.IconColor = System.Drawing.Color.Black;
            this.btnAceptarRed.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.btnAceptarRed.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnAceptarRed.Location = new System.Drawing.Point(175, 195);
            this.btnAceptarRed.Name = "btnAceptarRed";
            this.btnAceptarRed.Size = new System.Drawing.Size(243, 43);
            this.btnAceptarRed.TabIndex = 10;
            this.btnAceptarRed.Text = "ACEPTAR";
            this.btnAceptarRed.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnAceptarRed.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnAceptarRed.UseVisualStyleBackColor = true;
            this.btnAceptarRed.Click += new System.EventHandler(this.btnAceptarRed_Click);
            // 
            // btnAceptarMegas
            // 
            this.btnAceptarMegas.ForeColor = System.Drawing.Color.Black;
            this.btnAceptarMegas.IconChar = FontAwesome.Sharp.IconChar.Check;
            this.btnAceptarMegas.IconColor = System.Drawing.Color.Black;
            this.btnAceptarMegas.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.btnAceptarMegas.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnAceptarMegas.Location = new System.Drawing.Point(180, 197);
            this.btnAceptarMegas.Name = "btnAceptarMegas";
            this.btnAceptarMegas.Size = new System.Drawing.Size(243, 43);
            this.btnAceptarMegas.TabIndex = 10;
            this.btnAceptarMegas.Text = "ACEPTAR";
            this.btnAceptarMegas.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnAceptarMegas.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnAceptarMegas.UseVisualStyleBackColor = true;
            this.btnAceptarMegas.Click += new System.EventHandler(this.btnAceptarMegas_Click);
            // 
            // btnAceptarCable
            // 
            this.btnAceptarCable.ForeColor = System.Drawing.Color.Black;
            this.btnAceptarCable.IconChar = FontAwesome.Sharp.IconChar.Check;
            this.btnAceptarCable.IconColor = System.Drawing.Color.Black;
            this.btnAceptarCable.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.btnAceptarCable.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnAceptarCable.Location = new System.Drawing.Point(90, 239);
            this.btnAceptarCable.Name = "btnAceptarCable";
            this.btnAceptarCable.Size = new System.Drawing.Size(221, 43);
            this.btnAceptarCable.TabIndex = 4;
            this.btnAceptarCable.Text = "ACEPTAR";
            this.btnAceptarCable.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnAceptarCable.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnAceptarCable.UseVisualStyleBackColor = true;
            this.btnAceptarCable.Click += new System.EventHandler(this.btnAceptarCable_Click);
            // 
            // iconPictureBoxMegas
            // 
            this.iconPictureBoxMegas.BackColor = System.Drawing.Color.RoyalBlue;
            this.iconPictureBoxMegas.BackgroundImage = global::Empresa_Tigo.Properties.Resources.celular;
            this.iconPictureBoxMegas.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.iconPictureBoxMegas.ForeColor = System.Drawing.SystemColors.ControlText;
            this.iconPictureBoxMegas.IconChar = FontAwesome.Sharp.IconChar.None;
            this.iconPictureBoxMegas.IconColor = System.Drawing.SystemColors.ControlText;
            this.iconPictureBoxMegas.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconPictureBoxMegas.IconSize = 143;
            this.iconPictureBoxMegas.Location = new System.Drawing.Point(12, 394);
            this.iconPictureBoxMegas.Name = "iconPictureBoxMegas";
            this.iconPictureBoxMegas.Size = new System.Drawing.Size(196, 143);
            this.iconPictureBoxMegas.TabIndex = 16;
            this.iconPictureBoxMegas.TabStop = false;
            this.iconPictureBoxMegas.Click += new System.EventHandler(this.iconPictureBoxMegas_Click);
            // 
            // iconPictureBoxWifi
            // 
            this.iconPictureBoxWifi.BackColor = System.Drawing.Color.RoyalBlue;
            this.iconPictureBoxWifi.BackgroundImage = global::Empresa_Tigo.Properties.Resources.wifi;
            this.iconPictureBoxWifi.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.iconPictureBoxWifi.ForeColor = System.Drawing.SystemColors.ControlText;
            this.iconPictureBoxWifi.IconChar = FontAwesome.Sharp.IconChar.None;
            this.iconPictureBoxWifi.IconColor = System.Drawing.SystemColors.ControlText;
            this.iconPictureBoxWifi.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconPictureBoxWifi.IconSize = 143;
            this.iconPictureBoxWifi.Location = new System.Drawing.Point(12, 218);
            this.iconPictureBoxWifi.Name = "iconPictureBoxWifi";
            this.iconPictureBoxWifi.Size = new System.Drawing.Size(196, 143);
            this.iconPictureBoxWifi.TabIndex = 15;
            this.iconPictureBoxWifi.TabStop = false;
            this.iconPictureBoxWifi.Click += new System.EventHandler(this.iconPictureBoxWifi_Click);
            // 
            // iconPictureBoxTv_Cable
            // 
            this.iconPictureBoxTv_Cable.BackColor = System.Drawing.Color.RoyalBlue;
            this.iconPictureBoxTv_Cable.BackgroundImage = global::Empresa_Tigo.Properties.Resources.tv_cable;
            this.iconPictureBoxTv_Cable.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.iconPictureBoxTv_Cable.ForeColor = System.Drawing.SystemColors.ControlText;
            this.iconPictureBoxTv_Cable.IconChar = FontAwesome.Sharp.IconChar.None;
            this.iconPictureBoxTv_Cable.IconColor = System.Drawing.SystemColors.ControlText;
            this.iconPictureBoxTv_Cable.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconPictureBoxTv_Cable.IconSize = 143;
            this.iconPictureBoxTv_Cable.Location = new System.Drawing.Point(12, 42);
            this.iconPictureBoxTv_Cable.Name = "iconPictureBoxTv_Cable";
            this.iconPictureBoxTv_Cable.Size = new System.Drawing.Size(196, 143);
            this.iconPictureBoxTv_Cable.TabIndex = 14;
            this.iconPictureBoxTv_Cable.TabStop = false;
            this.iconPictureBoxTv_Cable.Click += new System.EventHandler(this.iconPictureBoxTv_Cable_Click);
            // 
            // FormPaquetes
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.RoyalBlue;
            this.ClientSize = new System.Drawing.Size(1210, 631);
            this.Controls.Add(this.grpMovil);
            this.Controls.Add(this.grpWifi);
            this.Controls.Add(this.grpTv_cable);
            this.Controls.Add(this.grpExtra);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.iconPictureBoxMegas);
            this.Controls.Add(this.iconPictureBoxWifi);
            this.Controls.Add(this.iconPictureBoxTv_Cable);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label2);
            this.Name = "FormPaquetes";
            this.Text = "FormPaquetes";
            this.grpExtra.ResumeLayout(false);
            this.grpExtra.PerformLayout();
            this.grpMovil.ResumeLayout(false);
            this.grpMovil.PerformLayout();
            this.grpTv_cable.ResumeLayout(false);
            this.grpTv_cable.PerformLayout();
            this.grpWifi.ResumeLayout(false);
            this.grpWifi.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.btnPara)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnHbo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnDisney)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.iconPictureBoxMegas)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.iconPictureBoxWifi)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.iconPictureBoxTv_Cable)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox grpExtra;
        private FontAwesome.Sharp.IconButton btnCancelar_Extra;
        private FontAwesome.Sharp.IconButton btnAceptar_Extra;
        private System.Windows.Forms.TextBox txtPlanExtra;
        private System.Windows.Forms.Label label12;
        private FontAwesome.Sharp.IconPictureBox btnPara;
        private FontAwesome.Sharp.IconPictureBox btnHbo;
        private FontAwesome.Sharp.IconPictureBox btnDisney;
        private System.Windows.Forms.GroupBox grpMovil;
        private FontAwesome.Sharp.IconButton btnAceptarMegas;
        private System.Windows.Forms.TextBox txtPrecioMegas;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.ComboBox cmbMegas;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.GroupBox grpTv_cable;
        private System.Windows.Forms.GroupBox grpWifi;
        private FontAwesome.Sharp.IconButton btnAceptarRed;
        private System.Windows.Forms.TextBox txtPrecioRed;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.ComboBox cmbRed;
        private FontAwesome.Sharp.IconButton btnAceptarCable;
        private System.Windows.Forms.TextBox txtPrecioCanales;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ComboBox cmbCanales;
        private FontAwesome.Sharp.IconPictureBox iconPictureBoxMegas;
        private FontAwesome.Sharp.IconPictureBox iconPictureBoxWifi;
        private FontAwesome.Sharp.IconPictureBox iconPictureBoxTv_Cable;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
    }
}