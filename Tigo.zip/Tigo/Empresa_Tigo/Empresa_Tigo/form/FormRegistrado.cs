﻿using Empresa_Tigo.Clases;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Empresa_Tigo.form
{
    public partial class FormRegistrado : Form
    {
        public FormRegistrado()
        {
            InitializeComponent();
        }

        private void grpExtra_Enter(object sender, EventArgs e) { }
        private void OcultarTodosLosGrupos()
        {
            grpTv_cable.Visible = false;
            grpWifi.Visible = false;
            grpMovil.Visible = false;
        }
        private void iconPictureBoxTv_Cable_Click(object sender, EventArgs e)
        {
            OcultarTodosLosGrupos();
            grpTv_cable.Visible = true;
        }

        private void iconPictureBoxWifi_Click(object sender, EventArgs e)
        {
            OcultarTodosLosGrupos();
            grpWifi.Visible = true;
        }

        private void iconPictureBoxMegas_Click(object sender, EventArgs e)
        {
            OcultarTodosLosGrupos();
            grpMovil.Visible = true;
        }

        private void btnAceptarCable_Click(object sender, EventArgs e)
        {
            if (cmbCanales.SelectedItem == null)
            {
                MessageBox.Show("Por favor selecciona un paquete de TV.", "Advertencia", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            string nombrePaquete = "tv-cable"; // Siempre fijo porque seleccionó TV
            string comproPaquete = cmbCanales.SelectedItem.ToString();
            decimal costoPaquete = decimal.Parse(txtPrecioCanales.Text);

            // Calcular fechas
            DateTime fechaInicial = DateTime.Now;
            DateTime fechaFinal = fechaInicial.AddDays(30);

            // Mostrar al usuario
            MessageBox.Show($"Fecha de inicio: {fechaInicial:dd/MM/yyyy}\nFecha de finalización: {fechaFinal:dd/MM/yyyy}", "Información de paquete", MessageBoxButtons.OK, MessageBoxIcon.Information);

            // Insertar en la BD sólo los datos que pediste
            try
            {
                using (SqlConnection conexion = estatica.BD_consultas.ObtenerConexion())
                {
                    conexion.Open();
                    string sql = @"INSERT INTO Paquete (nombre_paquete, compro_paquete, costo_paquete) 
                           VALUES (@nombre_paquete, @compro_paquete, @costo_paquete)";
                    using (SqlCommand cmd = new SqlCommand(sql, conexion))
                    {
                        cmd.Parameters.AddWithValue("@nombre_paquete", nombrePaquete);
                        cmd.Parameters.AddWithValue("@compro_paquete", comproPaquete);
                        cmd.Parameters.AddWithValue("@costo_paquete", costoPaquete);

                        cmd.ExecuteNonQuery();
                        MessageBox.Show("Paquete de TV guardado exitosamente.", "Éxito", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al guardar el paquete: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            grpExtra.Visible = true;
        }

        private void btnAceptarRed_Click(object sender, EventArgs e)
        {
            if (cmbRed.SelectedItem == null)
            {
                MessageBox.Show("Por favor selecciona un paquete de WiFi.", "Advertencia", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            string nombrePaquete = "wifi"; // nombre fijo
            string comproPaquete = cmbRed.SelectedItem.ToString();
            decimal costoPaquete = decimal.Parse(txtPrecioRed.Text);

            DateTime fechaInicial = DateTime.Now;
            DateTime fechaFinal = fechaInicial.AddDays(30);

            MessageBox.Show($"Fecha de inicio: {fechaInicial:dd/MM/yyyy}\nFecha de finalización: {fechaFinal:dd/MM/yyyy}", "Información de paquete", MessageBoxButtons.OK, MessageBoxIcon.Information);

            try
            {
                using (SqlConnection conexion = estatica.BD_consultas.ObtenerConexion())
                {
                    conexion.Open();
                    string sql = @"INSERT INTO Paquete (nombre_paquete, compro_paquete, costo_paquete) 
                           VALUES (@nombre_paquete, @compro_paquete, @costo_paquete)";
                    using (SqlCommand cmd = new SqlCommand(sql, conexion))
                    {
                        cmd.Parameters.AddWithValue("@nombre_paquete", nombrePaquete);
                        cmd.Parameters.AddWithValue("@compro_paquete", comproPaquete);
                        cmd.Parameters.AddWithValue("@costo_paquete", costoPaquete);

                        cmd.ExecuteNonQuery();
                        MessageBox.Show("Paquete de WiFi guardado exitosamente.", "Éxito", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al guardar el paquete: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            grpExtra.Visible = true;
        }

        private void btnAceptarMegas_Click(object sender, EventArgs e)
        {
            if (cmbMegas.SelectedItem == null)
            {
                MessageBox.Show("Por favor selecciona un paquete de Megas.", "Advertencia", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            string nombrePaquete = "movil"; // nombre fijo
            string comproPaquete = cmbMegas.SelectedItem.ToString();
            decimal costoPaquete = decimal.Parse(txtPrecioMegas.Text);

            DateTime fechaInicial = DateTime.Now;
            DateTime fechaFinal = fechaInicial.AddDays(30);

            MessageBox.Show($"Fecha de inicio: {fechaInicial:dd/MM/yyyy}\nFecha de finalización: {fechaFinal:dd/MM/yyyy}", "Información de paquete", MessageBoxButtons.OK, MessageBoxIcon.Information);

            try
            {
                using (SqlConnection conexion = estatica.BD_consultas.ObtenerConexion())
                {
                    conexion.Open();
                    string sql = @"INSERT INTO Paquete (nombre_paquete, compro_paquete, costo_paquete) 
                           VALUES (@nombre_paquete, @compro_paquete, @costo_paquete)";
                    using (SqlCommand cmd = new SqlCommand(sql, conexion))
                    {
                        cmd.Parameters.AddWithValue("@nombre_paquete", nombrePaquete);
                        cmd.Parameters.AddWithValue("@compro_paquete", comproPaquete);
                        cmd.Parameters.AddWithValue("@costo_paquete", costoPaquete);

                        cmd.ExecuteNonQuery();
                        MessageBox.Show("Paquete de Megas guardado exitosamente.", "Éxito", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al guardar el paquete: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            grpExtra.Visible = true;
        }
        private string servicioSeleccionado = "";

        private void btnDisney_Click(object sender, EventArgs e)
        {
            servicioSeleccionado = "Disney";
            txtPlanExtra.Text = "30";
        }

        private void btnHbo_Click(object sender, EventArgs e)
        {
            servicioSeleccionado = "HBO";
            txtPlanExtra.Text = "40";
        }

        private void btnPara_Click(object sender, EventArgs e)
        {
            servicioSeleccionado = "Paramount";
            txtPlanExtra.Text = "35";
        }
        private void btnAceptar_Extra_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(servicioSeleccionado))
            {
                MessageBox.Show("Debe seleccionar un servicio adicional.", "Advertencia", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            decimal precioExtra;
            if (!decimal.TryParse(txtPlanExtra.Text, out precioExtra))
            {
                MessageBox.Show("El precio no es válido.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // Insertar en la base de datos
            try
            {
                using (SqlConnection conexion = new SqlConnection(@"Data Source=DESKTOP-PAGR342\SQLEXPRESS;Initial Catalog=bd_Tigo;Integrated Security=True;Encrypt=False"))
                {
                    conexion.Open();

                    string sql = @"INSERT INTO Servicio_adicional (nombre, costo)
                           VALUES (@nombre, @costo)";

                    using (SqlCommand cmd = new SqlCommand(sql, conexion))
                    {
                        cmd.Parameters.AddWithValue("@nombre", servicioSeleccionado);
                        cmd.Parameters.AddWithValue("@costo", precioExtra);

                        cmd.ExecuteNonQuery();
                    }
                }

                MessageBox.Show("Servicio adicional registrado correctamente.", "Éxito", MessageBoxButtons.OK, MessageBoxIcon.Information);

                // Limpieza si quieres
                servicioSeleccionado = "";
                txtPlanExtra.Text = "";
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al insertar: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        
        private void grpWifi_Enter(object sender, EventArgs e)
        {
        }

        private void grpMovil_Enter(object sender, EventArgs e)
        {
        }
        private void grpTv_cable_Enter(object sender, EventArgs e)
        {
        }
        private void btnCancelar_Extra_Click(object sender, EventArgs e)
        {
            grpExtra.Visible = false;
        }

        private void cmbCanales_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmbCanales.SelectedItem == null) return;
            var texto = cmbCanales.SelectedItem.ToString();
            if (texto == "150 canales")
            {
                txtPrecioCanales.Text = "120";
            }
            if (texto == "200 canales")
            {
                txtPrecioCanales.Text = "150";
            }

            if (texto == "250 canales")
            {
                txtPrecioCanales.Text = "200";
            }
            if (texto == "300 canales")
            {
                txtPrecioCanales.Text = "250";
            }
        }

        private void cmbRed_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmbRed.SelectedItem == null) return;
            var texto = cmbRed.SelectedItem.ToString();
            if (texto == "100 megas")
            {
                txtPrecioRed.Text = "120";
            }
            if (texto == "150 megas")
            {
                txtPrecioRed.Text = "150";
            }

            if (texto == "200 megas")
            {
                txtPrecioRed.Text = "200";
            }
            if (texto == "250 megas")
            {
                txtPrecioRed.Text = "250";
            }
        }

        private void cmbMegas_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmbMegas.SelectedItem == null) return;
            var texto = cmbMegas.SelectedItem.ToString();
            if (texto == "300 mbps")
            {
                txtPrecioMegas.Text = "250";
            }
            if (texto == "150 mbps")
            {
                txtPrecioMegas.Text = "150";
            }

            if (texto == "100 mbps")
            {
                txtPrecioMegas.Text = "200";
            }
            if (texto == "200 mbps")
            {
                txtPrecioMegas.Text = "350";
            }
        }
    }
}
