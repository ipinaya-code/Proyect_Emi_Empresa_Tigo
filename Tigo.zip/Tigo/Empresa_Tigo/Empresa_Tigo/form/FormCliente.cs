﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Empresa_Tigo.Clases;


namespace Empresa_Tigo
{
    public partial class FormCliente : Form
    {
        public FormCliente()
        {
            InitializeComponent();
        }

        private void btnRegistrarse_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(textBox1.Text) || string.IsNullOrEmpty(textBox2.Text) || string.IsNullOrEmpty(textBox3.Text) || string.IsNullOrEmpty(textBox4.Text) || string.IsNullOrEmpty(textBox5.Text))
            {
                MessageBox.Show("Por favor, complete todos los campos.");
            }
            else
            {
                // Llama a la función de crear usuario pasando los valores de los campos
                estatica.BD_consultas.CrearUsuario(
                    textBox1.Text,         // nombreCliente
                    textBox2.Text,         // apellidoCliente
                    textBox3.Text,         // ci
                    textBox4.Text,         // telefono
                    textBox5.Text,         // email
                    textBox1.Text + textBox3.Text, // login (concatenación del nombre y el CI para crear un login)
                    textBox4.Text,         // password (usando el teléfono como contraseña por ahora, ajusta si es necesario)
                    true                    // estado (activo)
                );

                MessageBox.Show("Se registró exitosamente");
            }
        }
    }
}
