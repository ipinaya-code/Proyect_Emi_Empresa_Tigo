﻿using Empresa_Tigo.Clases;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Empresa_Tigo.form
{
    public partial class FormReducir : Form
    {
        public FormReducir()
        {
            InitializeComponent();
        }

        private void btnPaqueteNormal_Click(object sender, EventArgs e)
        {
            // Limpiamos primero
            dataGridView1.Columns.Clear();
            dataGridView1.Rows.Clear();

            // Creamos las columnas
            dataGridView1.Columns.Add("NombrePaquete", "Nombre del Paquete");
            dataGridView1.Columns.Add("CompraPaquete", "Compra Paquete");
            dataGridView1.Columns.Add("CostoPaquete", "Costo Paquete");

            // Ahora traemos los datos de la base de datos
            BaseDatos db = new BaseDatos();
            DataTable paquetes = db.ObtenerPaquetes();  // Este método lo creamos abajo

            // Llenamos el DataGridView
            foreach (DataRow row in paquetes.Rows)
            {
                dataGridView1.Rows.Add(row["nombre_paquete"], row["compro_paquete"], row["costo_paquete"]);
            }
        }

        private void btnPaqueteExtra_Click(object sender, EventArgs e)
        {
            // Limpiamos primero
            dataGridView1.Columns.Clear();
            dataGridView1.Rows.Clear();

            // Creamos las columnas
            dataGridView1.Columns.Add("NombreServicio", "Nombre del Servicio");
            dataGridView1.Columns.Add("CostoServicio", "Costo del Servicio");

            // Ahora traemos los datos de la base de datos
            BaseDatos db = new BaseDatos();
            DataTable servicios = db.ObtenerServiciosAdicionales(); // Este método lo creamos abajo

            // Llenamos el DataGridView
            foreach (DataRow row in servicios.Rows)
            {
                dataGridView1.Rows.Add(row["nombre_servicio"], row["costo_adicional"]);
            }
        }

        private void btnEliminar_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count > 0)
            {
                // Obtener el nombre de la primera columna de la fila seleccionada
                string nombre = dataGridView1.SelectedRows[0].Cells[0].Value.ToString();

                BaseDatos db = new BaseDatos();

                // Verificamos según qué columnas hay en el DataGridView para saber qué tabla es
                if (dataGridView1.Columns[0].Name == "NombrePaquete")
                {
                    // Eliminar de la tabla Paquete
                    db.EliminarPaquetePorNombre(nombre);
                }
                else if (dataGridView1.Columns[0].Name == "NombreServicio")
                {
                    // Eliminar de la tabla Servicio_Adicional
                    db.EliminarServicioAdicionalPorNombre(nombre);
                }

                // Eliminar también del DataGridView (interfaz)
                dataGridView1.Rows.RemoveAt(dataGridView1.SelectedRows[0].Index);

                MessageBox.Show("Eliminado correctamente.", "Eliminación", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                MessageBox.Show("Por favor seleccione una fila para eliminar.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }
    }
}
