﻿namespace Empresa_Tigo.form
{
    partial class FormAdmi
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.btnMostrarC_Adicional = new FontAwesome.Sharp.IconButton();
            this.btnMostrarS_Adicional = new FontAwesome.Sharp.IconButton();
            this.btnMostrarPaquetes = new FontAwesome.Sharp.IconButton();
            this.btnMostrarContratos = new FontAwesome.Sharp.IconButton();
            this.btnMostrarPago = new FontAwesome.Sharp.IconButton();
            this.btnMostrarClientes = new FontAwesome.Sharp.IconButton();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Lucida Sans Typewriter", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(362, 44);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(457, 40);
            this.label1.TabIndex = 1;
            this.label1.Text = "SECTOR ADMINISTRADOR";
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(362, 102);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 62;
            this.dataGridView1.RowTemplate.Height = 28;
            this.dataGridView1.Size = new System.Drawing.Size(806, 487);
            this.dataGridView1.TabIndex = 8;
            // 
            // btnMostrarC_Adicional
            // 
            this.btnMostrarC_Adicional.IconChar = FontAwesome.Sharp.IconChar.None;
            this.btnMostrarC_Adicional.IconColor = System.Drawing.Color.Black;
            this.btnMostrarC_Adicional.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.btnMostrarC_Adicional.Location = new System.Drawing.Point(62, 465);
            this.btnMostrarC_Adicional.Name = "btnMostrarC_Adicional";
            this.btnMostrarC_Adicional.Size = new System.Drawing.Size(256, 52);
            this.btnMostrarC_Adicional.TabIndex = 7;
            this.btnMostrarC_Adicional.Text = "Mostrar Contratos Extras";
            this.btnMostrarC_Adicional.UseVisualStyleBackColor = true;
            this.btnMostrarC_Adicional.Click += new System.EventHandler(this.btnMostrarC_Adicional_Click);
            // 
            // btnMostrarS_Adicional
            // 
            this.btnMostrarS_Adicional.IconChar = FontAwesome.Sharp.IconChar.None;
            this.btnMostrarS_Adicional.IconColor = System.Drawing.Color.Black;
            this.btnMostrarS_Adicional.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.btnMostrarS_Adicional.Location = new System.Drawing.Point(62, 395);
            this.btnMostrarS_Adicional.Name = "btnMostrarS_Adicional";
            this.btnMostrarS_Adicional.Size = new System.Drawing.Size(256, 52);
            this.btnMostrarS_Adicional.TabIndex = 6;
            this.btnMostrarS_Adicional.Text = "Mostrar Servicios Extras";
            this.btnMostrarS_Adicional.UseVisualStyleBackColor = true;
            this.btnMostrarS_Adicional.Click += new System.EventHandler(this.btnMostrarS_Adicional_Click);
            // 
            // btnMostrarPaquetes
            // 
            this.btnMostrarPaquetes.IconChar = FontAwesome.Sharp.IconChar.None;
            this.btnMostrarPaquetes.IconColor = System.Drawing.Color.Black;
            this.btnMostrarPaquetes.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.btnMostrarPaquetes.Location = new System.Drawing.Point(62, 324);
            this.btnMostrarPaquetes.Name = "btnMostrarPaquetes";
            this.btnMostrarPaquetes.Size = new System.Drawing.Size(256, 52);
            this.btnMostrarPaquetes.TabIndex = 5;
            this.btnMostrarPaquetes.Text = "Mostrar Paquetes";
            this.btnMostrarPaquetes.UseVisualStyleBackColor = true;
            this.btnMostrarPaquetes.Click += new System.EventHandler(this.btnMostrarPaquetes_Click);
            // 
            // btnMostrarContratos
            // 
            this.btnMostrarContratos.IconChar = FontAwesome.Sharp.IconChar.None;
            this.btnMostrarContratos.IconColor = System.Drawing.Color.Black;
            this.btnMostrarContratos.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.btnMostrarContratos.Location = new System.Drawing.Point(62, 253);
            this.btnMostrarContratos.Name = "btnMostrarContratos";
            this.btnMostrarContratos.Size = new System.Drawing.Size(256, 52);
            this.btnMostrarContratos.TabIndex = 4;
            this.btnMostrarContratos.Text = "Mostrar Contratos";
            this.btnMostrarContratos.UseVisualStyleBackColor = true;
            this.btnMostrarContratos.Click += new System.EventHandler(this.btnMostrarContratos_Click);
            // 
            // btnMostrarPago
            // 
            this.btnMostrarPago.IconChar = FontAwesome.Sharp.IconChar.None;
            this.btnMostrarPago.IconColor = System.Drawing.Color.Black;
            this.btnMostrarPago.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.btnMostrarPago.Location = new System.Drawing.Point(62, 184);
            this.btnMostrarPago.Name = "btnMostrarPago";
            this.btnMostrarPago.Size = new System.Drawing.Size(256, 52);
            this.btnMostrarPago.TabIndex = 3;
            this.btnMostrarPago.Text = "Mostrar Pagos";
            this.btnMostrarPago.UseVisualStyleBackColor = true;
            this.btnMostrarPago.Click += new System.EventHandler(this.btnMostrarPago_Click);
            // 
            // btnMostrarClientes
            // 
            this.btnMostrarClientes.IconChar = FontAwesome.Sharp.IconChar.None;
            this.btnMostrarClientes.IconColor = System.Drawing.Color.Black;
            this.btnMostrarClientes.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.btnMostrarClientes.Location = new System.Drawing.Point(62, 116);
            this.btnMostrarClientes.Name = "btnMostrarClientes";
            this.btnMostrarClientes.Size = new System.Drawing.Size(256, 52);
            this.btnMostrarClientes.TabIndex = 2;
            this.btnMostrarClientes.Text = "Mostrar Clientes";
            this.btnMostrarClientes.UseVisualStyleBackColor = true;
            this.btnMostrarClientes.Click += new System.EventHandler(this.btnMostrarClientes_Click);
            // 
            // FormAdmi
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.ClientSize = new System.Drawing.Size(1210, 631);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.btnMostrarC_Adicional);
            this.Controls.Add(this.btnMostrarS_Adicional);
            this.Controls.Add(this.btnMostrarPaquetes);
            this.Controls.Add(this.btnMostrarContratos);
            this.Controls.Add(this.btnMostrarPago);
            this.Controls.Add(this.btnMostrarClientes);
            this.Controls.Add(this.label1);
            this.Name = "FormAdmi";
            this.Text = "FormAdmi";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private FontAwesome.Sharp.IconButton btnMostrarClientes;
        private FontAwesome.Sharp.IconButton btnMostrarPago;
        private FontAwesome.Sharp.IconButton btnMostrarContratos;
        private FontAwesome.Sharp.IconButton btnMostrarPaquetes;
        private FontAwesome.Sharp.IconButton btnMostrarS_Adicional;
        private FontAwesome.Sharp.IconButton btnMostrarC_Adicional;
        private System.Windows.Forms.DataGridView dataGridView1;
    }
}