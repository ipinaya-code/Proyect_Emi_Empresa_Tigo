﻿//using Empresa_Tigo.Clases;
//using Empresa_Tigo.Clases;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;

namespace prueba
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()
        {
            /*BaseDatos db = new BaseDatos();
            string nombre = "TestNombre";
            string apellido = "TestApellido";
            string ci = "11122233";
            string tel = "555-0000";
            string email = "test@tigo.com";
            string login = "testuser";
            string pwd = "pwd123";
            bool estado = true;

            // Act
            db.CrearUsuario(nombre, apellido, ci, tel, email, login, pwd, estado);
            var usuario = db.BuscarPorLoginYPassword(login, pwd);

            // Assert
            Assert.IsNotNull(usuario);
            Assert.AreEqual(nombre, usuario.NombreCliente);
            Assert.AreEqual(apellido, usuario.ApellidoCliente);*/
        }
        [TestMethod]
        public void EliminarUsuario_Y_BuscarPorId_RetornaNull()
        {
            /*// Arrange
            var db = new BaseDatos();
            // Se asume existe un usuario con ID 99 para el test
            int idTest = 99;

            // Act
            db.EliminarUsuario(idTest);
            var usuario = db.BuscarPorId(idTest);

            // Assert
            Assert.IsNull(usuario);*/
        }


    }
}
