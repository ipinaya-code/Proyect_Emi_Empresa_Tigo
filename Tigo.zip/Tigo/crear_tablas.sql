create table Cliente(
    id_cliente int primary key identity(1,1),
    nombre_completo nvarchar(100) not null,
    apellido_completo nvarchar(100) not null,
    ci nvarchar(10) not null,
    telefono nvarchar(10) not null,
    email nvarchar(50) not null,
    login nvarchar(50) not null,  
    password nvarchar(50) not null,  
    estado bit not null
);

create table Paquete(
    id_paquete int primary key identity(1,1),
    nombre_paquete nvarchar(50) not null,
    compro_paquete nvarchar(50) not null,
    costo_paquete decimal(10,2) not null  
);

create table Servicio_adicional(
    id_servicio_adicional int primary key identity(1,1),
    nombre_servicio nvarchar(50) not null,
    costo_adicional decimal(10,2) not null  
);

create table Contrato(
    id_contrato int primary key identity(1,1),  
    fecha_inicio_contrato date not null,
    fecha_fin_contrato date null,
    estado_contrato bit not null,  
    id_cliente int not null,
    id_paquete int not null,
    foreign key(id_cliente) references Cliente(id_cliente),
    foreign key(id_paquete) references Paquete(id_paquete)
);

create table Contrato_Servicio_Adicional(
    id_contrato_adicional int primary key identity(1,1),  
    fecha_inicio_servicio date not null,
    fecha_fin_servicio date null,
    id_contrato int not null,
    id_servicio_adicional int not null,
    foreign key(id_contrato) references Contrato(id_contrato),
    foreign key(id_servicio_adicional) references Servicio_adicional(id_servicio_adicional)
);

create table Pago(
    id_pago int primary key identity(1,1),
    fecha_pago date not null,
    monto_pagado decimal(10,2) not null,  
    estado_pago bit not null,
    id_contrato int not null,
    foreign key(id_contrato) references Contrato(id_contrato)
);

select*from Cliente;
